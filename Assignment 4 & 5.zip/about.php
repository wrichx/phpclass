
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us</title>
    <ul >
        <li><a href="index.php">Home - Assignment 4</a></li>
        <li><a href="about.php">About - Procedural sample code</a></li>
        <li><a href="practice.php">Practice - oop sample code</a></li>
        <li><a href="Assign5.php">Assignment 5</a></li>
    </ul>
</head>
<body>
<h4> Procedural Code</h4>
<p>Below are insights of my thoughts on procedural programming</p>
<ol>
    <li>Highly repetitive code blocks</li>
    <li>Tedious to code and correct errors</li>
    <li>bulky coding</li>
    <li>Easy to mess up and create errors</li>

</ol>

<!--footer -->

<p>Developed by wr* || copyright 2018 || PHP OOP</p>
</body>
</html>