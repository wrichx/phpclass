<?php
/**
 * Created by PhpStorm.
 * User: wrx
 * Date: 28/09/2018
 * Time: 18:39
 */
//OOP with HTML
include_once ("header.html");
include_once "body.html";
include_once "footer.html";
