<?php
/**
 * Created by PhpStorm.
 * User: wrx
 * Date: 03/10/2018
 * Time: 00:53
 */

//header

include_once ("header.html");

//class - oop sample

class Students
    {
       //properties and value assignments
        public $name;
        public $student_id;
        public $course;
        public $assignment;
        public $attendance;
        public $projects;
//        public $ClassAttendance = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

        //methods

        public function CalculateAssignment ($unit, $marks)
            {
                $avgmark = $marks/ $unit;
                echo $avgmark. "<br>";
            }

        public function CalculateAttendance ($days, $participate)
            {
                if ($days == 5 && $participate == true) {
                    echo "You have passed this class";
                } else {
                    echo "You have Failed to qualify in the mandatory parameters";
                }
            }
    }

    //fetch
$score = new Students();
$score -> course = 'Software';
$score -> CalculateAssignment(5, 500);

$to_qualify = new Students();
$to_qualify -> attendance = 'must attend all 5 units';
$to_qualify -> CalculateAttendance(5, 0);