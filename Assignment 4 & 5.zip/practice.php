<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us</title>
</head>
<body>
<h4> OOP Code</h4>
<?php
include_once ("header.html");
include_once ("body.html");
include_once ("footer.html");
?>
</body>
</html>